package com.example.tic_tac_toe;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class player extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);
        final EditText e1=(EditText)findViewById(R.id.editText);
        final EditText e2=(EditText)findViewById(R.id.editText2);
        final Button button=(Button)findViewById(R.id.button11);
        final Button button1=(Button)findViewById(R.id.button12);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Intent i=new Intent(player.this,MainActivity.class);
                String p1=e1.getText().toString();
                String p2=e2.getText().toString();
                if(p1.length()!=0 && p2.length()!=0) {
                    i.putExtra("player1", p1);
                    i.putExtra("player2", p2);
                    startActivity(i);
                }
                else
                {
                    Toast.makeText(player.this, "Please Enter All Fields.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                e1.setText(null);
                e2.setText(null);
            }
        });
    }
}
