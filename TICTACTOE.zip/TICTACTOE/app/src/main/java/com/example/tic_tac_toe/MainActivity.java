package com.example.tic_tac_toe;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    int c=0,c1=2,i,j,cx=0,co=0;
    String status;
    String con="Congrats ";
    int[][] p=new int[3][3];

    void loop()
    {
        for(i=0;i<=2;i++)
        {
            for(j=0;j<=2;j++)
            {
                p[i][j]=c1;
                c1++;
            }
        }
    }

    String o="-->(O) WINS.";
    String x="-->(X) WINS.";
    String d="DRAW.";

    String win()
    {
        if((p[0][0]==p[0][1] && p[0][1]==p[0][2] && p[0][0]==p[0][2])||
                (p[1][0]==p[1][1] && p[1][1]==p[1][2] && p[1][0]==p[1][2])||
                (p[2][0]==p[2][1] && p[2][1]==p[2][2] && p[2][0]==p[2][2]))
        {
            if(c%2==0)
            {
                return o;
            }
            else{
                return  x;
            }
        }
        else if((p[0][0]==p[1][0] && p[1][0]==p[2][0] && p[0][0]==p[2][0])||
                (p[0][1]==p[1][1] && p[1][1]==p[2][1] && p[0][1]==p[2][1])||
                (p[0][2]==p[1][2] && p[1][2]==p[2][2] && p[0][2]==p[2][2]))
        {
            if(c%2==0)
            {
                return  o;
            }
            else{
                return x;
            }
        }
        else if ((p[0][0]==p[1][1] && p[1][1]==p[2][2] && p[0][0]==p[2][2])||
                (p[0][2]==p[1][1] && p[1][1]==p[2][0] && p[0][2]==p[2][0])
        )
        {
            if(c%2==0)
            {
                return o;
            }
            else{
                return x;
            }
        }
        else if(c==9)
        {
            return d;
        }

        return null;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button b1=(Button)findViewById(R.id.button);
        final Button b2=(Button)findViewById(R.id.button2);
        final Button b3=(Button)findViewById(R.id.button3);
        final Button b4=(Button)findViewById(R.id.button4);
        final Button b5=(Button)findViewById(R.id.button5);
        final Button b6=(Button)findViewById(R.id.button6);
        final Button b7=(Button)findViewById(R.id.button7);
        final Button b8=(Button)findViewById(R.id.button8);
        final Button b9=(Button)findViewById(R.id.button9);
        final Button bb=(Button)findViewById(R.id.button10);
        final TextView t=(TextView)findViewById(R.id.textView);
        final TextView t1=(TextView)findViewById(R.id.textView2);
        final TextView t2=(TextView)findViewById(R.id.textView3);
        final TextView t3=(TextView)findViewById(R.id.textView4);
        final TextView t4=(TextView)findViewById(R.id.textView5);

        loop();

        Intent intent=getIntent();
        Bundle bundle=intent.getExtras();
       final String px=bundle.getString("player1");
       final String po=bundle.getString("player2");

        t1.setText(px+" (X)");
        t2.setText(po+ " (O)");

        bb.setEnabled(false);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (c%2==0) {
                    b1.setText("X");
                    p[0][0]=1;
                }
                else{
                    b1.setText("O");
                    p[0][0]=0;
                }
//                b1.setBackgroundColor(Color.BLUE);
                b1.setEnabled(false);
                c++;
               status=win();
                if(status==o)
                {
                    t.setText(con+po+status);
                    co++;
                    String sco=Integer.toString(co);
                    t4.setText(sco);
                }
                else if(status==x)
                {
                    t.setText(con+px+status);
                    cx++;
                    String scx=Integer.toString(cx);
                    t3.setText(scx);
                }
                else if (status==d){
                    t.setText(status);
                }
                if (status==o || status==x || status==d)
                {
                    b1.setEnabled(false);
                    b2.setEnabled(false);
                    b3.setEnabled(false);
                    b4.setEnabled(false);
                    b5.setEnabled(false);
                    b6.setEnabled(false);
                    b7.setEnabled(false);
                    b8.setEnabled(false);
                    b9.setEnabled(false);
                    bb.setEnabled(true);
                }

            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (c%2==0) {
                    b2.setText("X");
                    p[0][1]=1;
                }
                else{
                    b2.setText("O");
                    p[0][1]=0;
                }
                b2.setEnabled(false);
                c++;
                status=win();
                if(status==o)
                {
                    t.setText(con+po+status);
                    co++;
                    String sco=Integer.toString(co);
                    t4.setText(sco);
                }
                else if(status==x)
                {
                    t.setText(con+px+status);
                    cx++;
                    String scx=Integer.toString(cx);
                    t3.setText(scx);
                }
                else if (status==d){
                    t.setText(status);
                }

                    if (status==o || status==x || status==d)
                    {
                        b1.setEnabled(false);
                        b2.setEnabled(false);
                        b3.setEnabled(false);
                        b4.setEnabled(false);
                        b5.setEnabled(false);
                        b6.setEnabled(false);
                        b7.setEnabled(false);
                        b8.setEnabled(false);
                        b9.setEnabled(false);
                        bb.setEnabled(true);
                    }


            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (c%2==0) {
                    b3.setText("X");
                    p[0][2]=1;
                }
                else{
                    b3.setText("O");
                    p[0][2]=0;
                }
                b3.setEnabled(false);
                c++;
                status=win();
                if(status==o)
                {
                    t.setText(con+po+status);
                    co++;
                    String sco=Integer.toString(co);
                    t4.setText(sco);
                }
                else if(status==x)
                {
                    t.setText(con+px+status);
                    cx++;
                    String scx=Integer.toString(cx);
                    t3.setText(scx);
                }
                else if (status==d){
                    t.setText(status);
                }

                    if (status==o || status==x || status==d)
                    {
                        b1.setEnabled(false);
                        b2.setEnabled(false);
                        b3.setEnabled(false);
                        b4.setEnabled(false);
                        b5.setEnabled(false);
                        b6.setEnabled(false);
                        b7.setEnabled(false);
                        b8.setEnabled(false);
                        b9.setEnabled(false);
                        bb.setEnabled(true);
                    }


            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (c%2==0) {
                    b4.setText("X");
                    p[1][0]=1;
                }
                else{
                    b4.setText("O");
                    p[1][0]=0;
                }
                b4.setEnabled(false);
                c++;
                status=win();

                if(status==o)
                {
                    t.setText(con+po+status);
                    co++;
                    String sco=Integer.toString(co);
                    t4.setText(sco);
                }
                else if(status==x)
                {
                    t.setText(con+px+status);
                    cx++;
                    String scx=Integer.toString(cx);
                    t3.setText(scx);
                }
                else if (status==d){
                    t.setText(status);
                }

                    if (status==o || status==x || status==d)
                    {
                        b1.setEnabled(false);
                        b2.setEnabled(false);
                        b3.setEnabled(false);
                        b4.setEnabled(false);
                        b5.setEnabled(false);
                        b6.setEnabled(false);
                        b7.setEnabled(false);
                        b8.setEnabled(false);
                        b9.setEnabled(false);
                        bb.setEnabled(true);
                    }


            }
        });
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (c%2==0) {
                    b5.setText("X");
                    p[1][1]=1;
                }
                else{
                    b5.setText("O");
                    p[1][1]=0;
                }
                b5.setEnabled(false);
                c++;
                status=win();
                if(status==o)
                {
                    t.setText(con+po+status);
                    co++;
                    String sco=Integer.toString(co);
                    t4.setText(sco);
                }
                else if(status==x)
                {
                    t.setText(con+px+status);
                    cx++;
                    String scx=Integer.toString(cx);
                    t3.setText(scx);
                }
                else if (status==d){
                    t.setText(status);
                }

                    if (status==o || status==x || status==d)
                    {
                        b1.setEnabled(false);
                        b2.setEnabled(false);
                        b3.setEnabled(false);
                        b4.setEnabled(false);
                        b5.setEnabled(false);
                        b6.setEnabled(false);
                        b7.setEnabled(false);
                        b8.setEnabled(false);
                        b9.setEnabled(false);
                        bb.setEnabled(true);
                    }


            }
        });
        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (c%2==0) {
                    b6.setText("X");
                    p[1][2]=1;
                }
                else{
                    b6.setText("O");
                    p[1][2]=0;
                }
                b6.setEnabled(false);
                c++;
                status=win();
                if(status==o)
                {
                    t.setText(con+po+status);
                    co++;
                    String sco=Integer.toString(co);
                    t4.setText(sco);
                }
                else if(status==x)
                {
                    t.setText(con+px+status);
                    cx++;
                    String scx=Integer.toString(cx);
                    t3.setText(scx);
                }
                else if (status==d){
                    t.setText(status);
                }

                    if (status==o || status==x || status==d)
                    {
                        b1.setEnabled(false);
                        b2.setEnabled(false);
                        b3.setEnabled(false);
                        b4.setEnabled(false);
                        b5.setEnabled(false);
                        b6.setEnabled(false);
                        b7.setEnabled(false);
                        b8.setEnabled(false);
                        b9.setEnabled(false);
                        bb.setEnabled(true);
                    }

            }
        });
        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (c%2==0) {
                    b7.setText("X");
                    p[2][0]=1;
                }
                else{
                    b7.setText("O");
                    p[2][0]=0;
                }
                b7.setEnabled(false);
                c++;
                status=win();
                if(status==o)
                {
                    t.setText(con+po+status);
                    co++;
                    String sco=Integer.toString(co);
                    t4.setText(sco);
                }
                else if(status==x)
                {
                    t.setText(con+px+status);
                    cx++;
                    String scx=Integer.toString(cx);
                    t3.setText(scx);
                }
                else if (status==d){
                    t.setText(status);
                }
                    if (status==o || status==x || status==d)
                    {
                        b1.setEnabled(false);
                        b2.setEnabled(false);
                        b3.setEnabled(false);
                        b4.setEnabled(false);
                        b5.setEnabled(false);
                        b6.setEnabled(false);
                        b7.setEnabled(false);
                        b8.setEnabled(false);
                        b9.setEnabled(false);
                        bb.setEnabled(true);
                    }


            }
        });
        b8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (c%2==0) {
                    b8.setText("X");
                    p[2][1]=1;
                }
                else{
                    b8.setText("O");
                    p[2][1]=0;
                }
                b8.setEnabled(false);
                c++;
                status=win();
                if(status==o)
                {
                    t.setText(con+po+status);
                    co++;
                    String sco=Integer.toString(co);
                    t4.setText(sco);
                }
                else if(status==x)
                {
                    t.setText(con+px+status);
                    cx++;
                    String scx=Integer.toString(cx);
                    t3.setText(scx);
                }
                else if (status==d){
                    t.setText(status);
                }
                    if (status==o || status==x || status==d)
                    {
                        b1.setEnabled(false);
                        b2.setEnabled(false);
                        b3.setEnabled(false);
                        b4.setEnabled(false);
                        b5.setEnabled(false);
                        b6.setEnabled(false);
                        b7.setEnabled(false);
                        b8.setEnabled(false);
                        b9.setEnabled(false);
                        bb.setEnabled(true);
                    }

            }
        });
        b9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (c%2==0) {
                    b9.setText("X");
                    p[2][2]=1;
                }
                else{
                    b9.setText("O");
                    p[2][2]=0;
                }
                b9.setEnabled(false);
                c++;
                status=win();
                if(status==o)
                {
                    t.setText(con+po+status);
                    co++;
                    String sco=Integer.toString(co);
                    t4.setText(sco);
                }
                else if(status==x)
                {
                    t.setText(con+px+status);
                    cx++;
                    String scx=Integer.toString(cx);
                    t3.setText(scx);
                }
                else if (status==d){
                    t.setText(status);
                }
                    if (status==o || status==x || status==d)
                    {
                        b1.setEnabled(false);
                        b2.setEnabled(false);
                        b3.setEnabled(false);
                        b4.setEnabled(false);
                        b5.setEnabled(false);
                        b6.setEnabled(false);
                        b7.setEnabled(false);
                        b8.setEnabled(false);
                        b9.setEnabled(false);
                        bb.setEnabled(true);
                    }
                }

        });
        bb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                recreate();
                loop();

//                if(status==o)
//                {
//                    co++;
//                    String sco=Integer.toString(co);
//                    t4.setText(sco);
//                }                                                            // code to set score
//                else if(status==x)
//                {
//                    cx++;
//                    String scx=Integer.toString(cx);
//                    t3.setText(scx);
//                }
                c=0;

                b1.setText(null);
                b2.setText(null);
                b3.setText(null);
                b4.setText(null);
                b5.setText(null);
                b6.setText(null);
                b7.setText(null);
                b8.setText(null);
                b9.setText(null);

                t.setText(null);

                b1.setEnabled(true);
                b2.setEnabled(true);
                b3.setEnabled(true);
                b4.setEnabled(true);
                b5.setEnabled(true);
                b6.setEnabled(true);
                b7.setEnabled(true);
                b8.setEnabled(true);
                b9.setEnabled(true);
                bb.setEnabled(false);
            }
        });
    }
}
